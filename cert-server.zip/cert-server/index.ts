import express, {
  Express,
  Request,
  Response,
  NextFunction,
  json,
  urlencoded,
} from "express";
import dotenv from "dotenv";
import cors from "cors";
import helmet from "helmet";
import cookie from "cookie-parser";

import { connectToDatabase } from "./plugins/connections";
import { verifyAccessToken } from "./plugins/tokens";

import booksRouter from "./apis/books";
import loansRouter from "./apis/loans";
import usersRouter from "./apis/users";

dotenv.config();

const app: Express = express();
const port: number = 8000;

const allowedURL: string[] = [
  process.env.CLIENT_URL || "http://localhost:3000",
];

app
  .use(
    cors({
      origin: allowedURL,
      credentials: true,
    })
  )
  .use(helmet())
  .use(helmet.crossOriginResourcePolicy({ policy: "cross-origin" }))
  .use(cookie())
  .use(json())
  .use(urlencoded({ extended: false }))
  .use((req: Request, res: Response, next: NextFunction): void => {
    try {
      const bearerHeader: string = req.headers["authorization"];
      const bearerToken: string = bearerHeader?.split(" ")[1];
      if (!bearerToken) throw new Error("UNAVAILABLE_TOKEN");
      const user = verifyAccessToken(bearerToken);
      Object.assign(req, { user });
      next();
    } catch {
      next();
    }
  });

app
  .use("/books", booksRouter)
  .use("/loans", loansRouter)
  .use("/users", usersRouter);

app.listen(port, async () => {
  try {
    await connectToDatabase();
    console.info(`server listening on http//localhost:${port}`);
  } catch (e) {
    console.error(`server crashed: ${e}`);
  }
});
