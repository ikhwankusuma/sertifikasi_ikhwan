import { Request, Response } from "express";

import { errorHandler } from "../../../plugins/errors";
import { findLoansByQuery } from "../../../connectors/loans/find-by-query";
import { Loan, LoanResponse } from "../../../types/loan";
import { findUserById } from "../../../connectors/users/find-by-id";
import { findBookById } from "../../../connectors/books/find-by-id";

export async function loanGetSearchController(req: Request, res: Response) {
  try {
    const {
      query: rawQuery,
    }: {
      query: any;
      user?: Request["user"];
    } = req;
    const {
      limit,
      skip,
    }: {
      limit?: number;
      skip?: number;
    } = rawQuery;

    const query: {
      limit?: number;
      skip?: number;
    } = {
      limit,
      skip,
    };

    const loans: Loan[] = await findLoansByQuery(query);

    const payload: LoanResponse[] = [];
    if (!loans.length) {
      res.status(200).send([]);
    }
    for (let i = 0; i < loans.length; i++) {
      const loan = loans[i];

      let r: LoanResponse = {
        _id: loan._id.toString(),
        user: {
          _id: loan.user_id.toString(),
          name: loan.user_id.toString(),
        },
        book: {
          _id: loan.book_id.toString(),
          name: loan.book_id.toString(),
        },
        borrow_date: loan.borrow_date,
        return_date: loan.return_date,
        state: loan.state,
      };

      const user = await findUserById(loan.user_id);
      const book = await findBookById(loan.book_id);

      if (user) {
        r.user.name = user.name;
      }
      if (book) {
        r.book.name = book.name;
      }

      payload.push(r);
      if (i === loans.length - 1) {
        res.status(200).send(payload);
      }
    }
  } catch (e) {
    errorHandler(e, res);
  }
}
