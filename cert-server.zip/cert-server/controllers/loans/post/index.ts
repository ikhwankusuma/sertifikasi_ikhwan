import { Request, Response } from "express";
import { InsertOneResult } from "mongodb";

import { LoanRequest } from "../../../types/loan";
import { createLoan } from "../../../connectors/loans/create";
import { errorHandler } from "../../../plugins/errors";

export async function loanPostController(req: Request, res: Response) {
  try {
    const {
      body: { book_id },
      user,
    }: {
      body: LoanRequest;
      user?: Request["user"];
    } = req;
    if (!user) throw new Error("UNAUTHORIZED");

    const payload: LoanRequest = {
      book_id,
      state: "borrowed",
    };

    const { insertedId: newLoanId }: InsertOneResult = await createLoan(
      payload,
      user._id
    );

    res.status(201).send(newLoanId.toString());
  } catch (e) {
    errorHandler(e, res);
  }
}
