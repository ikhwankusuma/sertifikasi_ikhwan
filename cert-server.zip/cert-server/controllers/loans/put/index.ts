import { Request, Response } from "express";
import { ObjectId } from "mongodb";

import { LoanRequest } from "../../../types/loan";
import { errorHandler } from "../../../plugins/errors";
import { findLoanById } from "../../../connectors/loans/find-by-id";
import { updateLoan } from "../../../connectors/loans/update";

export async function loanPutController(req: Request, res: Response) {
  try {
    const {
      params: { _id },
      body: { state },
      user,
    }: {
      params: {
        _id?: string;
      };
      body: LoanRequest;
      user?: Request["user"];
    } = req;
    if (!_id) throw new Error("LOAN_NOT_FOUND");

    const loan = await findLoanById(new ObjectId(_id));

    if (!user || loan.user_id.toString() !== user._id.toString())
      throw new Error("UNAUTHORIZED");

    console.log(loan);

    if (state === "returned") {
      loan.return_date = new Date().getTime();
    }
    loan.state = state;

    const { upsertedId } = await updateLoan(loan);

    res.status(200).send(upsertedId);
  } catch (e) {
    errorHandler(e, res);
  }
}
