import { Request, Response } from "express";
import { InsertOneResult } from "mongodb";

import { UserRequest, User } from "../../../types/user";
import { createUser } from "../../../connectors/users/create";

import { errorHandler } from "../../../plugins/errors";

export async function userPostController(req: Request, res: Response) {
  try {
    const {
      body: { name, email, password, phone },
    }: {
      body: UserRequest;
      user?: Request["user"];
    } = req;

    if (!name || typeof name !== "string")
      throw new Error("USER_MUST_HAVE_VALID_NAME");
    if (!email || typeof email !== "string")
      throw new Error("USER_MUST_HAVE_VALID_EMAIL");
    if (!password || typeof password !== "string")
      throw new Error("USER_MUST_HAVE_VALID_PASSWORD");

    const payload: UserRequest = {
      name,
      email,
      password,
      phone,
    };

    const { insertedId: newUserId }: InsertOneResult = await createUser(
      payload
    );

    res.status(201).send(newUserId.toString());
  } catch (e) {
    errorHandler(e, res);
  }
}
