import { Request, Response } from "express";
import { InsertOneResult } from "mongodb";

import { BookRequest } from "../../../types/book";
import { errorHandler } from "../../../plugins/errors";
import { verifyAction } from "../../../plugins/authentication";
import { createBook } from "../../../connectors/books/create";

export async function bookPostController(req: Request, res: Response) {
  try {
    const {
      body: { name, synopsis, author },
      user,
    }: {
      body: BookRequest;
      user?: Request["user"];
    } = req;
    if (!user || !(await verifyAction(user))) throw new Error("UNAUTHORIZED");

    const payload: BookRequest = {
      name,
      synopsis,
      author,
    };

    const { insertedId: newBookId }: InsertOneResult = await createBook(
      payload
    );

    res.status(201).send(newBookId.toString());
  } catch (e) {
    errorHandler(e, res);
  }
}
