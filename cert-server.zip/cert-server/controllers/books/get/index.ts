import { Request, Response } from "express";

import { findBooksByQuery } from "../../../connectors/books/find-by-query";
import { errorHandler } from "../../../plugins/errors";

export async function bookGetSearchController(req: Request, res: Response) {
  try {
    const {
      query,
    }: {
      query: any;
    } = req;
    const books = await findBooksByQuery(query);

    res.status(200).send(books);
  } catch (e) {
    errorHandler(e, res);
  }
}
