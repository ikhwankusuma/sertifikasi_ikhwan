import { Request } from "express";

export async function verifyAction(user: Request["user"]): Promise<boolean> {
  if (user.role === "admin") return true;
  return false;
}
