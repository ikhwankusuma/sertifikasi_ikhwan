import * as mongoDB from "mongodb";

import { Book } from "../types/book";
import { Loan } from "../types/loan";
import { User } from "../types/user";

interface Collections {
  books?: mongoDB.Collection<Book>;
  loans?: mongoDB.Collection<Loan>;
  users?: mongoDB.Collection<User>;
}

export const collections: Collections = {};

export async function connectToDatabase(): Promise<void> {
  const client: mongoDB.MongoClient = new mongoDB.MongoClient(
    process.env.MONGO_URL || "mongodb://localhost:27017"
  );
  await client.connect();

  const db: mongoDB.Db = client.db(process.env.MONGO_DB_NAME || "cert-node");

  collections.books = db.collection<Book>("books");
  collections.loans = db.collection<Loan>("loans");
  collections.users = db.collection<User>("users");
}
