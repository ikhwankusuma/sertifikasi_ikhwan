import { Router } from "express";

import { bookPostController } from "../controllers/books/post";
import { bookGetSearchController } from "../controllers/books/get";

const router: Router = Router();

router.post("/", bookPostController);
router.get("/", bookGetSearchController);

export default router;
