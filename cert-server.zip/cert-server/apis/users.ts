import { Router } from "express";

import { userPostController } from "../controllers/users/post";
import { userPostLoginController } from "../controllers/users/post-login";
import { userPostRefreshTokenController } from "../controllers/users/post-refresh-token";
import { userGetSearchController } from "../controllers/users/get";

const router: Router = Router();

router.post("/", userPostController);
router.post("/login", userPostLoginController);
router.post("/refresh-token", userPostRefreshTokenController);
router.get("/", userGetSearchController);

export default router;
