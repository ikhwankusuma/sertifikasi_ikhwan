import { Router } from "express";

import { loanPostController } from "../controllers/loans/post";
import { loanGetSearchController } from "../controllers/loans/get";
import { loanPutController } from "../controllers/loans/put";

const router: Router = Router();

router.post("/", loanPostController);
router.get("/", loanGetSearchController);
router.put("/:_id", loanPutController);

export default router;
