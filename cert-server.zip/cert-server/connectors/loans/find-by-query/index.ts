import { collections } from "../../../plugins/connections";
import { Loan } from "../../../types/loan";

export async function findLoansByQuery(query: any): Promise<Loan[]> {
  const result: Loan[] = (await collections.loans
    .find(query)
    .toArray()) as Loan[];
  return result;
}
