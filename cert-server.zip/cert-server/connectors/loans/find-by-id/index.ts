import { ObjectId } from "mongodb";
import { collections } from "../../../plugins/connections";
import { Loan } from "../../../types/loan";

export async function findLoanById(_id: ObjectId): Promise<Loan> {
  const result: Loan = (await collections.loans.findOne({
    _id,
  })) as Loan;
  return result;
}
