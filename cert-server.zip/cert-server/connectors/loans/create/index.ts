import { InsertOneResult, ObjectId } from "mongodb";

import { collections } from "../../../plugins/connections";
import { LoanRequest, Loan } from "../../../types/loan";

export async function createLoan(
  data: LoanRequest,
  user_id: ObjectId
): Promise<InsertOneResult> {
  const payload: Loan = {
    ...data,
    user_id,
    book_id: new ObjectId(data.book_id),
    _id: new ObjectId(),
    borrow_date: new Date().getTime(),
    state: "borrowed",
  };
  const result: InsertOneResult = await collections.loans.insertOne(payload);
  return result;
}
