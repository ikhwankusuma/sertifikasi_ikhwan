import { UpdateResult } from "mongodb";

import { collections } from "../../../plugins/connections";
import { Loan } from "../../../types/loan";

export async function updateLoan(data: Loan): Promise<UpdateResult> {
  const result: UpdateResult = await collections.loans.updateOne(
    { _id: data._id },
    { $set: { ...data } }
  );
  return result;
}
