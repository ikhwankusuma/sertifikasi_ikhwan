import { InsertOneResult, ObjectId } from "mongodb";

import { collections } from "../../../plugins/connections";
import { Book, BookRequest } from "../../../types/book";

export async function createBook(data: BookRequest): Promise<InsertOneResult> {
  const payload: Book = {
    ...data,
    _id: new ObjectId(),
  };
  const result: InsertOneResult = await collections.books.insertOne(payload);
  return result;
}
