import { collections } from "../../../plugins/connections";
import { Book } from "../../../types/book";

export async function findBooksByQuery(query: any): Promise<Book[]> {
  const result: Book[] = (await collections.books
    .find(query)
    .toArray()) as Book[];
  return result;
}
