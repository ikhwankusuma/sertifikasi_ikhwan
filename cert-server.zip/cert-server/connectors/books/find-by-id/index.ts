import { ObjectId } from "mongodb";

import { collections } from "../../../plugins/connections";
import { Book } from "../../../types/book";

export async function findBookById(_id: ObjectId): Promise<Book> {
  const result: Book = (await collections.books.findOne({ _id })) as Book;
  return result;
}
