import { AggregationCursor, Document, ObjectId } from "mongodb";

import { collections } from "../../../plugins/connections";
import { UserResponse } from "../../../types/user";

export async function getUserDataById(_id: ObjectId): Promise<UserResponse> {
  const pipeline: Document[] = [
    {
      $match: {
        $expr: {
          $eq: ["$_id", _id],
        },
      },
    },
    {
      $project: {
        _id: "$_id",
        name: "$name",
        email: "$email",
        phone: "$phone",
        address: "$address",
        role: "$role",
      },
    },
  ];

  const payload: UserResponse[] = [];
  const cursor: AggregationCursor<UserResponse> =
    collections.users.aggregate(pipeline);
  for await (const doc of cursor) {
    payload.push(doc);
  }

  return payload[0];
}
