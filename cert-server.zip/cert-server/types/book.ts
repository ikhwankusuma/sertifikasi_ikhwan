import { ObjectId } from "mongodb";

export type BookRequest = {
  name: string;
  synopsis: string;
  author: string;
  image_url?: string;
};

export type Book = {
  _id: ObjectId;
  name: string;
  synopsis: string;
  author: string;
  image_url?: string;
};

export type BookResponse = {
  _id: string;
  name: string;
  synopsis: string;
  author: string;
  image_url?: string;
};
