<template>
  <div class="layout">
    <div class="header">
      <button v-if="user?.role === 'admin'" @click="addBook">Add Book</button>
    </div>
    <div class="container">
      <div v-for="book in books" :key="book._id" class="book">
        <div class="information">
          <div class="author">{{ book.author }}</div>
          <div class="name">{{ book.name }}</div>
          <div class="synopsis">{{ book.synopsis }}</div>
        </div>
        <div class="book-action">
          <button
            v-if="loanedUser.findIndex((a) => a[0] === book._id) > -1"
            @click="returnBook(book._id)"
          >
            Kembalikan
          </button>
          <button
            v-else-if="loanedAll.findIndex((a) => a[0] === book._id) > -1"
            disabled
          >
            Pinjam
          </button>
          <button v-else @click="borrowBook(book._id)">Pinjam</button>
        </div>
      </div>
    </div>
  </div>
  <add-book-panel v-if="addBookOpened" @exit="addBookExit" />
  <user-login-panel v-if="!user" @create="userCreateOpened = true" />
  <user-create-panel v-if="userCreateOpened" @exit="userCreateOpened = false" />
</template>

<script lang="ts" setup>
  import { LoanRequest } from "./types/loan";

  const { init, view, rem } = useMain();
  const { books, getBook } = useBook();
  const { loans, getLoan, createLoan, updeteLoan } = useLoan();
  const { user } = useUser();

  const routeLoading = ref<boolean>(true);

  const addBookOpened = ref<boolean>(false);
  const userCreateOpened = ref<boolean>(false);

  const loanedUser = computed<[string, string][]>(() => {
    // [book_id, loan_id]
    if (!user.value) return [];
    const v = loans.value.filter(
      (a) => a.state === "borrowed" && a.user._id === user.value?._id
    );
    return v.map((a) => [a.book._id, a._id]);
  });
  const loanedAll = computed<[string, string][]>(() => {
    // [book_id, loan_id]
    const v = loans.value.filter((a) => a.state === "borrowed");
    return v.map((a) => [a.book._id, a._id]);
  });

  function resizeHandler(e: MediaQueryList | MediaQueryListEvent): void {
    if (e.matches) view.value = "mobile";
    else view.value = "desktop";
    rem.value = parseInt(getComputedStyle?.(document.body)?.fontSize) || 24;
  }

  watch(
    () => view.value,
    (val, oldVal) => {
      if (val && oldVal) location.reload();
    }
  );
  watch(
    () => init.value,
    (val, oldVal) => {
      if (oldVal && !val) routeLoading.value = false;
    }
  );

  async function returnBook(book_id: string): Promise<void> {
    const request: LoanRequest = {
      book_id,
      state: "returned",
    };

    const index = loanedUser.value.findIndex((a) => a[0] === book_id);
    if (index > -1) {
      await updeteLoan({ loan_id: loanedUser.value[index][1], request });
      await getLoan();
    }
  }
  async function borrowBook(book_id: string): Promise<void> {
    const request: LoanRequest = {
      book_id,
      state: "borrowed",
    };
    await createLoan({ request });
    await getLoan();
  }
  function addBook(): void {
    addBookOpened.value = !addBookOpened.value;
  }
  function addBookExit(): void {
    addBookOpened.value = false;
    getBook();
  }

  watch(
    () => user.value,
    (val) => {
      console.log(val);
    },
    { deep: true, immediate: true }
  );
  watch(
    () => loanedUser.value,
    (val) => {
      console.log(val);
    },
    { deep: true, immediate: true }
  );
  // watch(
  //   () => loanedAll.value,
  //   (val) => {
  //     console.log(val);
  //   },
  //   { deep: true, immediate: true }
  // );

  onBeforeMount(() => {
    const mediaQuery: MediaQueryList = window.matchMedia("(max-width: 1024px)");
    mediaQuery.addEventListener("change", resizeHandler);
    resizeHandler(mediaQuery);
  });

  onMounted(async () => {
    getBook();
    getLoan();

    const mediaQuery: MediaQueryList = window.matchMedia("(max-width: 1024px)");
    mediaQuery.addEventListener("change", resizeHandler);
    resizeHandler(mediaQuery);

    document.documentElement.style.setProperty(
      "--vh",
      `${window.innerHeight * 0.01}px`
    );
    window.addEventListener("resize", () => {
      document.documentElement.style.setProperty(
        "--vh",
        `${window.innerHeight * 0.01}px`
      );
    });
  });
</script>

<style lang="scss" scoped>
  .layout {
    position: relative;
    width: 100%;
    min-height: 100vh;
    padding: 2rem;
    box-sizing: border-box;
    background: rgba(0, 0, 0, 0.01);
    display: flex;
    flex-direction: column;
    gap: 2rem;
    .header {
      position: relative;
      width: 100%;
      height: 2rem;
      display: flex;
      * {
        height: 2rem;
      }
    }
    .container {
      position: relative;
      width: 100%;
      height: calc(100% - 4rem);
      display: flex;
      flex-wrap: wrap;
      gap: 2rem;
      .book {
        position: relative;
        width: calc((100vw - 14rem) / 6);
        height: calc((100vw - 14rem) / 6);
        background: #fff;
        border-radius: 1rem;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        .information {
          position: relative;
          width: 100%;
          height: 100%;
          padding: 1rem;
          box-sizing: border-box;
          display: flex;
          flex-direction: column;
          gap: 0.25rem;
          .name {
            position: relative;
            font-size: 20px;
          }
          .author {
            position: relative;
            font-size: 16px;
          }
          .synopsis {
            position: relative;
            font-size: 12px;
          }
        }
        .book-action {
          position: absolute;
          bottom: 0;
          width: 100%;
          padding: 1rem;
          box-sizing: border-box;
          button {
            width: 100%;
          }
        }
      }
    }
  }
</style>

<style lang="scss">
  :root {
    -webkit-tap-highlight-color: transparent;
    --primary-color: #ffd975;
    --secondary-color: #242529;
    --error-color: #ff584c;
    --warning-color: #ffd975;
    --success-color: #6bc785;
    --border-color: #f0f0f0;
    --font-primary-color: #242529;
    --font-secondary-color: #242529;
    --font-sub-color: rgba(36, 37, 41, 0.5);
    --background-depth-one-color: #ffffff;
    --background-depth-two-color: #fafafa;
    --background-depth-three-color: #f0f0f0;
    --border: 1px solid var(--border-color);
    --box-shadow: 0 0.5rem 1rem rgba(199, 199, 199, 0.125);
  }

  ::-webkit-scrollbar {
    display: none;
  }

  html,
  body {
    position: relative;
    width: 100vw;
    margin: 0;
    padding: 0;
    font-size: 24px;
    font-family: "Poppins", -apple-system, BlinkMacSystemFont, sans-serif;
    color: var(--font-primary-color);
    background: var(--background-depth-two-color);
    overflow-x: hidden;

    @media only screen and (max-width: 1900px) and (min-width: 1600px) {
      font-size: 22px;
    }

    @media only screen and (max-width: 1599px) and (min-width: 1480px) {
      font-size: 21px;
    }

    @media only screen and (max-width: 1479px) and (min-width: 1380px) {
      font-size: 20px;
    }

    @media only screen and (max-width: 1379px) and (min-width: 1320px) {
      font-size: 19px;
    }

    @media only screen and (max-width: 1319px) and (min-width: 1024px) {
      font-size: 18px;
    }

    @media only screen and (max-width: 640px) {
      font-size: 24px;
    }

    @media only screen and (max-width: 320px) {
      font-size: 17px;
    }

    @media only screen and (max-width: 1024px) {
      height: auto;
      overflow-y: auto;

      .rd-title-1 {
        font-size: 1.25rem;
      }

      .rd-title-2 {
        font-size: 1.125rem;
      }
    }

    &.rd-dark {
      --primary-color: #fff37a;
      --warning-color: #fff37a;
      --background-depth-one-color: #2d2e32;
      --background-depth-two-color: #242529;
      --background-depth-three-color: #202124;
      --border-color: #222327;
      --box-shadow: 0 0.5rem 1rem rgba(15, 16, 17, 0.25);
      --font-primary-color: #fdebdd;
      --font-secondary-color: #242529;
      --font-sub-color: rgba(253, 235, 221, 0.375);
    }
  }

  .rd-title-1 {
    font-size: 1.75rem;
    font-weight: 700;
    font-family: "Poppins";
  }

  .rd-title-2 {
    font-size: 1.375rem;
    font-weight: 700;
    font-family: "Poppins";
  }

  .rd-headline-1 {
    font-size: 1.25rem;
    font-weight: 600;
    font-family: "Poppins";
  }

  .rd-headline-2 {
    font-size: 1rem;
    font-weight: 600;
    font-family: "Poppins";
  }

  .rd-headline-3 {
    font-size: 0.85rem;
    font-weight: 600;
    font-family: "Poppins";
  }

  .rd-headline-4 {
    font-size: 0.75rem;
    font-weight: 600;
    font-family: "Poppins";
  }

  .rd-headline-5 {
    font-size: 0.65rem;
    font-weight: 600;
    font-family: "Poppins";
  }

  .rd-headline-6 {
    font-size: 0.55rem;
    font-weight: 600;
    font-family: "Poppins";
  }

  .rd-subtitle-text {
    font-size: 0.75rem;
    font-weight: 500;
    font-family: "Poppins";
  }

  .rd-body-text {
    font-size: 0.6rem;
    font-weight: 500;
    font-family: "Poppins";
  }

  .rd-caption-text {
    font-size: 0.55rem;
    font-family: "Poppins";
    font-weight: 500;
    color: var(--font-sub-color);
  }

  .rd-button-text {
    font-family: "Poppins";
    font-size: 0.55rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.125rem;
    transform: translateX(0.0625rem);
  }

  span.rd-text-wrapper,
  span.rd-word-wrapper,
  span.rd-letter-wrapper,
  span.rd-image-wrapper {
    position: relative;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: flex-start;

    span.rd-text-container,
    span.rd-word-container,
    span.rd-letter-container,
    span.rd-image-container {
      position: relative;
      overflow: hidden;
      display: flex;
      justify-content: center;
      align-items: center;

      &.rd-text-container-up,
      &.rd-word-container-up,
      &.rd-letter-container-up,
      &.rd-image-container-up {
        transform: translateY(-100%);

        span.rd-text,
        span.rd-word,
        span.rd-letter,
        img.rd-image {
          transform: translateY(100%);

          &.rd-image:not(.rd-image-contain) {
            transform: translateY(100%) scale(1.25);
          }

          &.rd-image-contain {
            object-fit: contain;
            transform: translateY(100%) scale(1);
          }
        }
      }

      &.rd-text-container-down,
      &.rd-word-container-down,
      &.rd-letter-container-down,
      &.rd-image-container-down {
        transform: translateY(100%);

        span.rd-text,
        span.rd-word,
        span.rd-letter,
        img.rd-image {
          transform: translateY(-100%);

          &.rd-image:not(.rd-image-contain) {
            transform: translateY(-100%) scale(1.25);
          }

          &.rd-image-contain {
            object-fit: contain;
            transform: translateY(-100%) scale(1);
          }
        }
      }

      &.rd-text-container-left,
      &.rd-word-container-left,
      &.rd-letter-container-left,
      &.rd-image-container-left {
        transform: translateX(-100%);

        span.rd-text,
        span.rd-word,
        span.rd-letter,
        img.rd-image {
          transform: translateX(100%);

          &.rd-image:not(.rd-image-contain) {
            transform: translateX(100%) scale(1.25);
          }

          &.rd-image-contain {
            object-fit: contain;
            transform: translateX(100%) scale(1);
          }
        }
      }

      &.rd-text-container-right,
      &.rd-word-container-right,
      &.rd-letter-container-right,
      &.rd-image-container-right {
        transform: translateX(100%);

        span.rd-text,
        span.rd-word,
        span.rd-letter,
        img.rd-image {
          transform: translateX(-100%);

          &.rd-image:not(.rd-image-contain) {
            transform: translateX(-100%) scale(1.25);
          }

          &.rd-image-contain {
            object-fit: contain;
            transform: translateX(-100%) scale(1);
          }
        }
      }
    }
  }

  span.rd-image-wrapper {
    width: 100%;
    height: 100%;

    span.rd-image-container {
      width: 100%;
      height: 100%;

      img.rd-image {
        position: relative;
        width: 100%;
        height: 100%;
        object-fit: cover;
        transform: scale(1.25);
      }
    }
  }

  h1,
  h2,
  h3,
  h4,
  h5,
  h6,
  p {
    margin: 0;
    padding: 0;
  }

  @keyframes rd-loading {
    0% {
      left: 0;
      right: 100%;
    }

    50% {
      left: 0;
      right: 0;
    }

    100% {
      left: 100%;
      right: 0;
    }
  }

  @keyframes rd-shake {
    0% {
      transform: translate(1px, 1px);
    }

    10% {
      transform: translate(-1px, -2px);
    }

    20% {
      transform: translate(-3px, 0px);
    }

    30% {
      transform: translate(3px, 2px);
    }

    40% {
      transform: translate(1px, -1px);
    }

    50% {
      transform: translate(-1px, 2px);
    }

    60% {
      transform: translate(-3px, 1px);
    }

    70% {
      transform: translate(3px, 1px);
    }

    80% {
      transform: translate(-1px, -1px);
    }

    90% {
      transform: translate(1px, 2px);
    }

    100% {
      transform: translate(1px, -2px);
    }
  }

  @keyframes rd-rotate {
    0% {
      transform: rotate(0deg);
    }

    100% {
      transform: rotate(360deg);
    }
  }

  @keyframes rd-circular-rotate {
    0% {
      transform: rotate(0);
    }

    50% {
      transform: rotate(-140deg);
    }

    100% {
      transform: rotate(0);
    }
  }
</style>
