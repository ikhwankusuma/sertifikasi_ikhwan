export type BookRequest = {
  name: string;
  synopsis: string;
  author: string;
  image_url?: string;
};

export type Book = {
  _id: string;
  name: string;
  synopsis: string;
  author: string;
  image_url?: string;
};
