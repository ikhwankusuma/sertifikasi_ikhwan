export type LoanRequest = {
  book_id: string;
  state: "borrowed" | "returned";
};

export type Loan = {
  _id: string;
  book: {
    _id: string;
    name: string;
  };
  user: {
    _id: string;
    name: string;
  };
  borrow_date: number;
  return_date?: number;
  state: "borrowed" | "returned";
};
