export type View = "desktop" | "mobile" | null;
