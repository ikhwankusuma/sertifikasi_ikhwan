// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  runtimeConfig: {
    public: {
      apiBase: process.env.API_URL || "http://localhost:8000",
      base: process.env.BASE_URL || "http://localhost:3000",
    },
  },
  app: {
    head: {
      title: "Library Management System",
      htmlAttrs: {
        lang: "id",
      },
      meta: [
        { charset: "utf-8" },
        {
          name: "viewport",
          content:
            "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no",
        },
        { name: "format-detection", content: "telephone=no" },
        { name: "googlebot", content: "notranslate" },
      ],
      link: [
        {
          rel: "preconnect",
          href: process.env.API_URL,
          crossorigin: "use-credentials",
        },
      ],
    },
  },
});
