<template>
  <div class="container"></div>
</template>

<script lang="ts" setup>
  const { state } = useMain();

  onMounted(async () => {
    setTimeout(() => {
      state.value = "idle";
    }, 250);
  });
</script>

<style lang="scss" scoped></style>
