<template>
  <div class="overlay">
    <form class="container">
      <h1>Buat akun</h1>
      <div class="wrapper">
        <label>Nama</label>
        <input type="text" v-model="name" required />
      </div>
      <div class="wrapper">
        <label>Nomor telpon</label>
        <input type="text" v-model="phone" required />
      </div>
      <div class="wrapper">
        <label>Alamat</label>
        <input type="text" v-model="address" required />
      </div>
      <div class="wrapper">
        <label>Email</label>
        <input type="text" v-model="email" required />
      </div>
      <div class="wrapper">
        <label>Password</label>
        <input type="password" v-model="password" required />
      </div>
      <button @click.prevent="submit">Simpan</button>
      <button @click.prevent="emits('exit')">Tutup</button>
    </form>
  </div>
</template>

<script lang="ts" setup>
  import { UserRequest } from "~/types/user";

  const { createUser } = useUser();
  const emits = defineEmits(["exit"]);

  const name = ref<UserRequest["name"]>("");
  const phone = ref<UserRequest["phone"]>("");
  const address = ref<UserRequest["address"]>("");
  const email = ref<UserRequest["email"]>("");
  const password = ref<UserRequest["password"]>("");

  async function submit(): Promise<void> {
    const request: UserRequest = {
      name: name.value,
      email: email.value,
      password: password.value,
      phone: phone.value,
      address: address.value,
    };
    const user = await createUser({ request });

    if (user) {
      emits("exit");
    } else {
      window.alert("Buat akun gagal");
      name.value = "";
      phone.value = "";
      address.value = "";
      email.value = "";
      password.value = "";
    }
  }
</script>

<style lang="scss" scoped>
  .overlay {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(20px);
    display: flex;
    justify-content: center;
    align-items: center;
    .container {
      position: relative;
      border-radius: 1rem;
      padding: 1rem;
      background: #fff;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      .wrapper {
        position: relative;
        display: flex;
        flex-direction: column;
        gap: 0.25rem;
        label {
          font-size: 16px;
        }
      }
    }
  }
</style>
