<template>
  <div class="overlay">
    <form class="container">
      <h1>Tambah buku</h1>
      <div class="wrapper">
        <label>Judul</label>
        <input type="text" v-model="name" required />
      </div>
      <div class="wrapper">
        <label>Penulis</label>
        <input type="text" v-model="author" required />
      </div>
      <div class="wrapper">
        <label>Sinopsis</label>
        <input type="text" v-model="synopsis" required />
      </div>
      <button @click.prevent="submit">Simpan</button>
      <button @click.prevent="emits('exit')">Tutup</button>
    </form>
  </div>
</template>

<script lang="ts" setup>
  import { BookRequest } from "~/types/book";

  const { createBook } = useBook();
  const emits = defineEmits(["exit"]);

  const name = ref<BookRequest["name"]>("");
  const synopsis = ref<BookRequest["synopsis"]>("");
  const author = ref<BookRequest["author"]>("");

  async function submit(): Promise<void> {
    const request: BookRequest = {
      name: name.value,
      author: author.value,
      synopsis: synopsis.value,
    };

    await createBook({ request });
    emits("exit");
  }
</script>

<style lang="scss" scoped>
  .overlay {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(20px);
    display: flex;
    justify-content: center;
    align-items: center;
    .container {
      position: relative;
      border-radius: 1rem;
      padding: 1rem;
      background: #fff;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      .wrapper {
        position: relative;
        display: flex;
        flex-direction: column;
        gap: 0.25rem;
        label {
          font-size: 16px;
        }
      }
    }
  }
</style>
