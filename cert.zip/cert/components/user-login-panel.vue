<template>
  <div class="overlay">
    <form class="container">
      <h1>Login</h1>
      <div class="wrapper">
        <label>Email</label>
        <input type="text" v-model="email" required />
      </div>
      <div class="wrapper">
        <label>Password</label>
        <input type="password" v-model="password" required />
      </div>
      <button @click.prevent="submit">Simpan</button>
      <button @click.prevent="emits('create')">Daftar</button>
    </form>
  </div>
</template>

<script lang="ts" setup>
  const { login } = useUser();
  const emits = defineEmits(["exit", "create"]);

  const email = ref<string>("");
  const password = ref<string>("");

  async function submit(): Promise<void> {
    const user = await login(email.value, password.value);

    if (user) {
      emits("exit");
    } else {
      window.alert("Login gagal");
      email.value = "";
      password.value = "";
    }
  }
</script>

<style lang="scss" scoped>
  .overlay {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(20px);
    display: flex;
    justify-content: center;
    align-items: center;
    .container {
      position: relative;
      border-radius: 1rem;
      padding: 1rem;
      background: #fff;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      .wrapper {
        position: relative;
        display: flex;
        flex-direction: column;
        gap: 0.25rem;
        label {
          font-size: 16px;
        }
      }
    }
  }
</style>
