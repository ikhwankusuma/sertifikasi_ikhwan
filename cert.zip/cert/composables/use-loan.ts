import { Loan, LoanRequest } from "~~/types/loan";

export default function () {
  const { $fetch } = useNuxtApp();
  const { public: env } = useRuntimeConfig();

  const loans = useState<Loan[]>("loans", () => []);

  async function getLoan(): Promise<Loan[]> {
    try {
      const response = await $fetch(`${env.apiBase}/loans`, "get");

      if (response.status === 404) return [];
      if (response.status !== 200) throw await response.text();

      loans.value = await response.json();
      return loans.value;
    } catch (e) {
      return [];
    }
  }
  async function createLoan(payload: {
    request: LoanRequest;
  }): Promise<Loan | null> {
    try {
      const response = await $fetch(
        `${env.apiBase}/loans`,
        "post",
        JSON.stringify(payload.request)
      );

      if (response.status !== 201) throw await response.text();

      const result = await response.json();
      loans.value.unshift(result);

      return result;
    } catch (e) {
      return null;
    }
  }
  async function updeteLoan(payload: {
    loan_id: string;
    request: LoanRequest;
  }): Promise<string> {
    try {
      const response = await $fetch(
        `${env.apiBase}/loans/${payload.loan_id}`,
        "put",
        JSON.stringify(payload.request)
      );

      if (response.status !== 200) throw await response.text();

      const result = await response.text();
      await getLoan();

      return result;
    } catch (e) {
      return "";
    }
  }
  async function deleteLoan(loan_id: string): Promise<void> {
    try {
      const response = await $fetch(
        `${env.apiBase}/loans/${loan_id}`,
        "delete"
      );

      if (response.status !== 204) throw await response.text();

      const index = loans.value.findIndex((a) => a._id === loan_id);
      if (index > -1) {
        loans.value.splice(index, 1);
      }
    } catch (e) {}
  }

  return { loans, getLoan, createLoan, updeteLoan, deleteLoan };
}
