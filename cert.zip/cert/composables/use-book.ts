import { Book, BookRequest } from "~~/types/book";

export default function () {
  const { $fetch } = useNuxtApp();
  const { public: env } = useRuntimeConfig();

  const books = useState<Book[]>("books", () => []);

  async function getBook(): Promise<Book[]> {
    try {
      const response = await $fetch(`${env.apiBase}/books`, "get");

      if (response.status === 404) return [];
      if (response.status !== 200) throw await response.text();

      books.value = await response.json();
      return books.value;
    } catch (e) {
      return [];
    }
  }
  async function createBook(payload: {
    request: BookRequest;
  }): Promise<Book | null> {
    try {
      const response = await $fetch(
        `${env.apiBase}/books`,
        "post",
        JSON.stringify(payload.request)
      );

      if (response.status !== 201) throw await response.text();

      const result = await response.json();
      books.value.unshift(result);

      return result;
    } catch (e) {
      return null;
    }
  }
  async function updeteBook(payload: {
    book_id: string;
    request: BookRequest;
  }): Promise<string> {
    try {
      const response = await $fetch(
        `${env.apiBase}/books/${payload.book_id}`,
        "put",
        JSON.stringify(payload.request)
      );

      if (response.status !== 200) throw await response.text();

      const result = await response.text();
      await getBook();

      return result;
    } catch (e) {
      return "";
    }
  }
  async function deleteBook(book_id: string): Promise<void> {
    try {
      const response = await $fetch(
        `${env.apiBase}/books/${book_id}`,
        "delete"
      );

      if (response.status !== 204) throw await response.text();

      const index = books.value.findIndex((a) => a._id === book_id);
      if (index > -1) {
        books.value.splice(index, 1);
      }
    } catch (e) {}
  }

  return { books, getBook, createBook, updeteBook, deleteBook };
}
